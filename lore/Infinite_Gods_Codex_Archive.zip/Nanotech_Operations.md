# ⚙️ Nanotech Operations Codex

## Overview
Describes nanite types, operational layers, medical and combat usage, replication limits, and AI-control integration.